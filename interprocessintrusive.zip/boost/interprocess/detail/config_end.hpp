#if defined BOOST_MSVC
   #pragma warning (pop)
   #ifdef BOOST_INTERPROCESS_CRT_SECURE_NO_DEPRECATE
   #undef BOOST_INTERPROCESS_CRT_SECURE_NO_DEPRECATE
   #undef _CRT_SECURE_NO_DEPRECATE
   #endif
#endif

