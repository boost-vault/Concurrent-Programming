//  Some algorithm tests to see what was fastest

//  Copyright Clint Levijoki 2006. Use, modification, and distribution are
//  subject to the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)


#include <iostream>
#include <algorithm>
#include <vector>
#include <boost/thread.hpp>
#include <boost/progress.hpp>

#include "test_vector.hpp"
#include "test_algorithm.hpp"
#include "test_thread_pool.hpp"
#include "test_thread_width.hpp"

template<typename T>
inline bool _IsPrime( T number )
{
    T end = number/2;
    for( T i = 2; i < end; i++ )
    {
        if( number % i == 0 )
            return false;
    }

    return true;
}

template<typename T>
class StdIsPrime
{
    int &result;
public:

    StdIsPrime( int& result ) : result(result) {}
    inline void operator()( T i )
    {
        if( _IsPrime( i ) )
        {
            result++;
        }
    }
};

template<typename T>
class ParallelIsPrime
{
    int& result;
    boost::mutex& m;
public:

    ParallelIsPrime( int& result, boost::mutex& m ) : result(result), m(m) {}
    inline void operator()( T i )
    {
        if( _IsPrime( i ) )
        {
            boost::mutex::scoped_lock lock( m );
            result++;
        }
    }
};

template<typename T>
class StdSimpleFilter
{
public:
    StdSimpleFilter( int &result ) {}

    inline void operator()( T& i )
    {
        int _i = i;

        // some nonsensical filter
        if( _i % 3 == 0 )
        {
            i = 3;
        }
        else if( _i % 5 == 0 )
        {
            i = 5;
        }
        else if( _i % 7 == 0 )
        {
            i = 7;
        }
        else if( _i % 13 == 0 )
        {
            i = 13;
        }
    }
};


template<typename T>
class ParallelSimpleFilter
{
public:
    // these parameters are here just to make it compile
    ParallelSimpleFilter( int& result, boost::mutex& m ) {}

    inline void operator()( T& i )
    {
        int _i = i;

        // some nonsensical filter
        if( _i % 3 == 0 )
        {
            i = 3;
        }
        else if( _i % 5 == 0 )
        {
            i = 5;
        }
        else if( _i % 7 == 0 )
        {
            i = 7;
        }
        else if( _i % 13 == 0 )
        {
            i = 13;
        }
    }
};


class Person
{
public:
    std::string firstName;
    std::string lastName;
    int age;

    inline bool operator==( const Person& other )
    {
        return other.firstName == firstName &&
            other.lastName == lastName &&
            other.age == age;
    }
};

template <typename T> T get_random_value();

template <> Person get_random_value<Person>()
{
    Person p;
    p.age = rand();

    switch( rand()/(RAND_MAX/4) )
    {
    case 0:
        p.firstName = "Billy";
        break;
    case 1:
        p.firstName = "Blake";
        break;
    case 2:
        p.firstName = "Benjamin";
        break;
    case 3:
        p.firstName = "Bob";
        break;
    }

    switch( rand()/(RAND_MAX/4) )
    {
    case 0:
        p.lastName = "Billiam";
        break;
    case 1:
        p.lastName = "Blakeson";
        break;
    case 2:
        p.lastName = "Benjaminson";
        break;
    case 3:
        p.lastName = "Bobberson";
        break;
    }

    return p;
}

template <> int get_random_value<int>()
{
    int i = rand();
    if( i == 678 )
        i = 0;

    return i;
}

template <typename T>
void std_find_test( T find, int length, int repeat )
{
    std::vector<T> svec( length );

    for( int i = 0; i < length; i++ )
    {
        svec[i] = get_random_value<T>();
    }

    svec[length-1] = find;

    // now do the same search with a single thread
    {
        perf::timer t;

        for( int i = 0; i < repeat; i++ )
        {
            std::vector<T>::iterator result = std::find( svec.begin(), svec.end(), find );
        }

        t.add_interval();
        std::cout << "total : " << t.get_total() << " sec\n";
    }
}


template <typename T, typename _FuncType>
void parallel_find_test( T find, int length, int repeat, _FuncType& func )
{
    test::parallel_vector<T> pvec( length ); 

    for( int i = 0; i < length; i++ )
    {
        pvec[i] = get_random_value<T>();
    }

    pvec[length-1] = find;

    // do the searches with 2 threads:
    perf::timer t;
    
    for( int i = 0; i < repeat; i++ )
    {
        MARK_TIMER( setup_overhead );
        test::parallel_vector<T>::iterator result = func( pvec, find );
        ADD_TIMER( setup_overhead );
    }

    t.add_interval();
    std::cout << "total : " << t.get_total() << " sec\n";
}

template <typename T,typename _FuncType>
void std_for_each_test( unsigned length, unsigned repeat )
{
    std::vector<T> vec( length );
    for( unsigned i = 0; i < length; i++ )
        vec[i] = (i+1)*2-1;

    int result = 0;

    perf::timer t;

    for( unsigned n = 0; n < repeat; n++ )
    {
        std::for_each( vec.begin(), vec.end(), _FuncType( result ) );
    }

    t.add_interval();

    std::cout << "total : " << t.get_total() << " sec\n";
}

template <typename T, typename _FuncType>
void parallel_for_each_test( unsigned length, unsigned repeat )
{
    test::parallel_vector<T> vec( length );
    for( unsigned i = 0; i < length; i++ )
        vec[i] = (i+1)*2-1;

    boost::mutex m;
    int result = 0;

    perf::timer t;

    for( unsigned n = 0; n < repeat; n++ )
    {
        MARK_TIMER( setup_overhead );
        test::parallel_for_each_all( vec, _FuncType( result, m ) );
        ADD_TIMER( setup_overhead );
    }

    t.add_interval();
    std::cout << "total : " << t.get_total() << " sec\n";

}


void main()
{
    std::cout << "parallel stl containers test 2, Clint Levijoki 2006\n";
    std::cout << "compiled for " << global_thread_width << " processors\n\n";

    // pre-initialize the thread pool
    test::thread_pool::get_default();

//    std_find_test( 777, 666, 1000, 2000 );
//    parallel_find_test( 777, 666, 1000, 2000, test::parallel_find_all2<test::parallel_vector<int>,int> );

    
    
    std::cout << "\nTest 1: stress overhead\n";

    std::cout << "   std::find ";
    std_find_test( 678, 10000, 20000 );
    std::cout << "   parallel::find ";
    RESET_TIMERS( setup_overhead );
    parallel_find_test( 678, 10000, 20000, test::parallel_find_all<test::parallel_vector<int>,int> );
    PRINT_OVERHEAD();
    

    Person minority = { "James", "Gimbal", 33 };

    std::cout << "\nTest 2: object searching\n";

    std::cout << "   std::find ";
    std_find_test( minority, 200000, 1000 );
    std::cout << "   parallel::find ";
    RESET_TIMERS( setup_overhead );
    parallel_find_test( minority, 200000, 1000, test::parallel_find_all<test::parallel_vector<Person>,Person> );
    PRINT_OVERHEAD();
   
    std::cout << "\nTest 3: simple for each filter\n";

    std::cout << "   std::for_each ";
    std_for_each_test<int,StdSimpleFilter<int>>( 2000, 1000 );
    std::cout << "   parallel::for_each ";

    RESET_TIMERS( setup_overhead );
    parallel_for_each_test<int,ParallelSimpleFilter<int>>( 2000, 1000 );
    PRINT_OVERHEAD();
    
    std::cout << "\nTest 4: prime numbers\n";

    std::cout << "   std::for_each ";
    std_for_each_test<int,StdIsPrime<int>>( 75000, 1 );
    std::cout << "   parallel::for_each ";
    RESET_TIMERS( setup_overhead );
    parallel_for_each_test<int,ParallelIsPrime<int>>( 75000, 1 );
    PRINT_OVERHEAD();
}