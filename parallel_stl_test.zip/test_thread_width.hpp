//  Adjust this if you wish to compile for different processor counts.

//  Copyright Clint Levijoki 2006. Use, modification, and distribution are
//  subject to the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)


#ifndef __THREAD_WIDTH_HPP__
#define __THREAD_WIDTH_HPP__

#ifndef _THREAD_COUNT

#define _THREAD_POOL_COUNT 2
#define STR2(n) #n
#define STR(n) STR2(n)

#pragma message ("Default _THREAD_POOL_COUNT = " STR(_THREAD_POOL_COUNT))
#endif
    enum { global_thread_width = _THREAD_POOL_COUNT };

#endif