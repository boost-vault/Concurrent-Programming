//	a timer class because I didn't trust the boost ones with the small timeslices I was dealing with

//  Copyright Clint Levijoki 2006. Use, modification, and distribution are
//  subject to the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)


#pragma once
#include <windows.h>
#include <math.h>

// Remove the cost of calling QueryPerformanceCounter in critical timing areas
//#define NO_PERF_TIMERS

#include <boost/utility.hpp>

namespace perf
{
    class timer : boost::noncopyable
    {
    public:
        timer::timer()
        {
            reset();
        }

        inline void reset()
        {
            _total.QuadPart = 0;
            mark();
        }
        
        inline void mark()
        {
            QueryPerformanceCounter( &_mark );
        }


        inline void add_interval()
        {
            LARGE_INTEGER t;
            QueryPerformanceCounter( &t );

            _total.QuadPart += t.QuadPart-_mark.QuadPart;
        }

        double get_total()
        {
            LARGE_INTEGER freq;
            QueryPerformanceFrequency( &freq );

            double d = double(_total.QuadPart)/double(freq.QuadPart);

            return ceil( d*10000 )*0.0001;

        }

    private:
        LARGE_INTEGER _total, _mark;
    };

    extern timer setup_overhead;
    extern timer pool_overhead;
    extern timer wait0;
    extern timer wait1;
    extern timer thread0;
    extern timer thread1;
    extern timer *current_timer;

#ifndef NO_PERF_TIMERS
#   define MARK_TIMER( tm ) perf::tm.mark();
#   define ADD_TIMER( tm ) perf::tm.add_interval();
#   define RESET_TIMERS( initial ) { perf::setup_overhead.reset(); perf::pool_overhead.reset(); perf::wait0.reset(); perf::wait1.reset(); perf::thread0.reset(); perf::thread1.reset(); perf::current_timer = &perf::initial; }
#   define PRINT_OVERHEAD() { std::cout << "     overhead  => setup: " << perf::setup_overhead.get_total() << " pool: " << perf::pool_overhead.get_total() << " wait0: " << perf::wait0.get_total() << " wait1: " << perf::wait1.get_total() << "\n" <<\
                                           "     execution => cpu_0: " << perf::thread0.get_total() << " cpu_1: " << perf::thread1.get_total() << "\n"; }
#   define SET_TIMER_SECTION( tm ) { perf::current_timer->add_interval(); perf::current_timer = &perf::tm; perf::current_timer->mark(); }
#else
#   define MARK_TIMER( tm ) /**/
#   define ADD_TIMER( tm ) /**/
#   define RESET_TIMERS() /**/
#   define PRINT_OVERHEAD() /**/
#endif
}

