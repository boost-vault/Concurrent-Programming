//  This is some random hackery to get a parallel container to function.

//  Copyright Clint Levijoki 2006. Use, modification, and distribution are
//  subject to the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __TEST_VECTOR_HPP__
#define __TEST_VECTOR_HPP__


#include <vector>
#include <algorithm>
#include <boost/thread.hpp>

#include "test_thread_width.hpp"


namespace test
{


// note: none of this is inherently threadsafe, I still think that would be best for the end user to do
// (the algorithm functions can still be threadsafe)

template<typename _Type>
class parallel_vector
{
public:
    typedef std::vector<_Type> pvector;
    typedef typename pvector::size_type size_type;
    typedef typename pvector::iterator iterator;
    typedef typename pvector::const_iterator const_iterator;
    typedef typename pvector::reference reference;
    typedef typename pvector::const_reference const_reference;

private:

    size_type total_size;
    std::vector<pvector*> data;

public:
    explicit parallel_vector( size_type size ) : total_size(size), data(global_thread_width)
    {
        for( int i = 0; i < global_thread_width; i++ )
            data[i] = new std::vector<_Type>;
        resize(size);
    }

    inline void resize( size_type size )
    {
        total_size = size;
        size_type left = total_size;

        size_type psize = total_size/global_thread_width;
        if( size % global_thread_width )
            psize++;

        for( size_type i = 0; i < global_thread_width; i++ )
        {
            data[i]->resize( std::min( left, psize ) );

            left -= psize;
        }
    }

    inline iterator begin( size_type thread )
    {
        return data[thread]->begin();
    }

    inline iterator end( size_type thread )
    {
        return data[thread]->end();
    }

    inline const_iterator begin( size_type thread ) const
    {
        return data[thread]->begin();
    }

    inline const_iterator end( size_type thread ) const
    {
        return data[thread]->end();
    }

    inline const_reference operator[]( size_type pos ) const
    {
        return (*data[pos%global_thread_width])[pos/global_thread_width];
    }

    inline reference operator[]( size_type pos )
    {
        return (*data[pos%global_thread_width])[pos/global_thread_width];
    }

    inline void push_back( const _Type& t )
    {
        data[total_size%global_thread_width]->push_back( t );

        total_size++;
    }

    inline size_type size()
    {
        return total_size;
    }

    /*
    serial_iterator begin()
    {
        // return an iterator that can be used by a serial program, and possibly
        // be read by the parallel allocator functions to  
    }
    */
};

}

#endif