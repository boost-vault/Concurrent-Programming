//  This high-speed thread pool is actually quite good and will probably be the only thing I'll keep
//  from all of this code.

//  Copyright Clint Levijoki 2006. Use, modification, and distribution are
//  subject to the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)


#ifndef __THREAD_POOL_HPP__
#define __THREAD_POOL_HPP__

#include <queue>
#include <boost/thread.hpp>
#include <boost/bind.hpp>

#include "test_thread_width.hpp"
#include "perftimer.hpp"

namespace test
{


    typedef struct
    {
        typedef void (*thread_proc)(void*);

        void *data;
        thread_proc proc;

        inline void do_job()
        {
            proc(data);
        }
    }job;

    class thread_pool
    {
        volatile bool threads_active;

        // this class just manages the number of workers still left on a task
        class worker_boss
        {
            boost::mutex mutex;
            boost::condition workers_not_done;
            int worker_count;

        public:
            inline explicit worker_boss() : worker_count( 0 ) {}

            inline void add_worker()
            {
                boost::mutex::scoped_lock lock( mutex );
                worker_count++;
            }

            inline void wait_for_workers()
            {
                boost::mutex::scoped_lock lock( mutex );

                while( worker_count != 0 )
                    workers_not_done.wait( lock );
            }

            inline void worker_done()
            {
                boost::mutex::scoped_lock lock( mutex );
                worker_count--;
                workers_not_done.notify_one();
            }
        };

        class worker_thread
        {
            thread_pool *pool;

            boost::thread* thread;
            boost::mutex has_job_mutex;
            boost::condition still_unemployed;

            job *current_job;
            worker_boss *current_boss;
        public:
            explicit worker_thread( thread_pool *pool ) : 
              pool(pool), 
              current_job(0),
              current_boss(0)
            {
                thread = new boost::thread( boost::bind(&worker_thread::thread_func,this) );
            }

            inline void set_job( job* j, worker_boss *boss )
            {
                boost::mutex::scoped_lock lock( has_job_mutex );

                current_job = j;
                current_boss = boss;

                // this is the line that will notify our thread that we have work waiting
                still_unemployed.notify_one();
            }

        private:

            inline job *get_next_job()
            {
                boost::mutex::scoped_lock lock( has_job_mutex );

                while( current_job == 0 )
                    still_unemployed.wait( lock );

                return current_job;
            }

            inline void job_done()
            {
                // notifies a task instance that this thread is done
                current_boss->worker_done();
                // this returns it to the global pool

                current_job = 0;
                current_boss = 0;

                pool->return_worker_thread( this );
            }

            void thread_func()
            {
                while( true )
                {
                    // get_next_job will wait if there are no more jobs left
                    job * j = get_next_job();
                    ADD_TIMER( wait1 );

                    MARK_TIMER( thread1 );
                    j->do_job();
                    ADD_TIMER( thread1 );

                    // now we're done, notify the required peoples
                    MARK_TIMER( wait1 );
                    job_done();
                    ADD_TIMER( wait1 );
                }
            }
        };


        boost::mutex worker_queue_mutex;
        boost::condition no_more_worker_threads;

        std::queue<worker_thread*> worker_queue;
        volatile bool worker_queue_empty;

        inline worker_thread* get_worker_thread()
        {
            boost::mutex::scoped_lock lock( worker_queue_mutex );

            worker_thread *t = worker_queue.front();
            worker_queue.pop();

            worker_queue_empty = worker_queue.empty();
            return t;
        }

        inline void return_worker_thread( worker_thread* t )
        {
            boost::mutex::scoped_lock lock( worker_queue_mutex );

            worker_queue_empty = false;

            worker_queue.push( t );
        }

    public:
        explicit thread_pool( int size )
        {
            threads_active = true;
            for( int i = 0; i < size; i++ )
            {
                worker_thread *t = new worker_thread( this );

                return_worker_thread( t );
            }
        }

        ~thread_pool()
        {
            threads_active = false;

            while( !worker_queue_empty )
                delete get_worker_thread();
        }

        inline static thread_pool* get_default()
        {
            static thread_pool pool( global_thread_width );
            return &pool;
        }

        // this always expects a job array that is global_thread_width long
        inline void parallel_run( job *jobs )
        {
            // this coordinates our workers
            worker_boss boss;

            int current_job = 0;
            ADD_TIMER( pool_overhead );

            do
            {
                MARK_TIMER( pool_overhead );
                // reserve as many worker threads as we can, up to tasks left-1
                while( !worker_queue_empty && current_job < global_thread_width-1 )
                {

                    worker_thread *wt = get_worker_thread();
                    boss.add_worker();

                    MARK_TIMER( wait0 );
                    MARK_TIMER( wait1 );    // this is resolved in our timer thread
                    wt->set_job( &jobs[current_job++], &boss );
                    ADD_TIMER( wait0 );
                }

                SET_TIMER_SECTION( thread0 );
                jobs[current_job++].do_job();
                SET_TIMER_SECTION( pool_overhead );
            }
            while( current_job < global_thread_width );

            // wait for our worker threads, if necessary
            MARK_TIMER( wait0 );
            boss.wait_for_workers();
            ADD_TIMER( wait0 );
        }
    };
    
}

#endif