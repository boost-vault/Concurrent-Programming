//  Some algorithm tests to see what was fastest

//  Copyright Clint Levijoki 2006. Use, modification, and distribution are
//  subject to the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __TEST_ALGORITHM_HPP__
#define __TEST_ALGORITHM_HPP__

#include <cstdlib>
#include <stack>
#include <boost/thread.hpp>
#include "test_vector.hpp"
#include "test_thread_pool.hpp"

#include "perftimer.hpp"


namespace test
{
// use the thread pool:

template<typename _ItrType,typename _TargetType>
struct find_data
{
    find_data() {}

    boost::mutex* m;
    _ItrType start;
    _ItrType end;

    const _TargetType *target;

    volatile bool* found;
    _ItrType* result;
    int *result_depth;
    int our_depth;
};

template<typename _ItrType,typename _TargetType>
void find_func_thread_callback( void *data )
{
    typedef typename struct find_data<_ItrType,_TargetType> _DataType;

    _DataType *fd = reinterpret_cast<_DataType*>( data );

    // making local copies of this data is faster
    int our_depth = fd->our_depth;
    _ItrType start = fd->start;
    _ItrType end = fd->end;
    const _TargetType target = *fd->target;

    for( ; start != end; ++start )
    {
        if( *start == target )
        {
            boost::mutex::scoped_lock lock( *fd->m );
            
            if( !fd->found || our_depth < *fd->result_depth )
            {
                *fd->result = fd->start;
                *fd->result_depth = our_depth;
            }
            return;
        }

        our_depth += global_thread_width;
    }
}

template<typename _PContainerType, typename _TargetType>
inline typename _PContainerType::iterator parallel_find_all( _PContainerType& container, const _TargetType& value )
{
    typedef typename _PContainerType::iterator _ItrType;
    typedef typename struct find_data<_ItrType,_TargetType> _DataType;

    test::job jobs[global_thread_width];
    _DataType data[global_thread_width];

    boost::mutex results_mutex;
    volatile bool found = false;
    _ItrType result;
    int result_depth = 0;

    for( int i = 0; i < global_thread_width; i++ )
    {
        data[i].m = &results_mutex;
        data[i].start = container.begin(i);
        data[i].end = container.end(i);

        data[i].target = &value;
        data[i].found = &found;
        data[i].result = &result;

        data[i].result_depth = &result_depth;

        data[i].our_depth = i;

        jobs[i].data = &data[i];

        jobs[i].proc = static_cast<job::thread_proc>( test::find_func_thread_callback<_ItrType,_TargetType> );
    }



    SET_TIMER_SECTION( pool_overhead );

    test::thread_pool::get_default()->parallel_run( jobs );
    
    SET_TIMER_SECTION( setup_overhead );
    if( found )
        return result;

    return container.end(0);
}

template <typename _ItrType,typename _FunctionType>
struct fef_data
{
    inline fef_data() {}

    _ItrType begin;
    _ItrType end;
    _FunctionType* func;
};

template <typename _ItrType,typename _FunctionType>
void for_each_func_callback( void *data )
{
    struct fef_data<_ItrType,_FunctionType> *fdata = reinterpret_cast<struct fef_data<_ItrType,_FunctionType>*>( data );
    std::for_each( fdata->begin, fdata->end, *fdata->func );
}

template<typename _PContainerType, typename _FunctionType>
inline const _FunctionType& parallel_for_each_all( _PContainerType& container, _FunctionType& f )
{
    typedef typename _PContainerType::iterator itr_type;
    typedef typename struct fef_data<itr_type,_FunctionType> data_type;

    test::job jobs[global_thread_width];
    data_type data[global_thread_width];

    for( int i = 0; i < global_thread_width; i++ )
    {
        data[i].begin = container.begin(i);
        data[i].end = container.end(i);
        data[i].func = &f;

        jobs[i].data = &data[i];
        jobs[i].proc = static_cast<job::thread_proc>( test::for_each_func_callback<itr_type,_FunctionType> );
    }

    SET_TIMER_SECTION( pool_overhead );

    test::thread_pool::get_default()->parallel_run( jobs );

    SET_TIMER_SECTION( setup_overhead );
    return f;
}
}
#endif