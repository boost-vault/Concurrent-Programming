//-----------------------------------------------------------------------------
// boost-libs futures/test/join_test.cpp source file
// See http://www.boost.org for updates, documentation, and revision history.
//-----------------------------------------------------------------------------
//
// Copyright (c) 2005
// Thorsten Schuett
//
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cmath>
#include <boost/test/minimal.hpp>
#include <boost/futures.hpp>

int fac(int n){
  if(n == 0)
    return 0;
  if(n == 1)
    return 1;
  return n * fac(n - 1);
}

double fac8()
{
    return (double)fac(8);
}

struct fac_functor
{
    fac_functor(int n) : n(n) {}
    
    int operator()()
    {
        return fac(n);
    } 
    
    int n;
};

bool equal(double d1, double d2){
  return fabs(d1 - d2) < 0.001;
}

int test_main(int , char* [])
{
  using namespace boost::futures;
  using namespace boost;


  simple_future<int>    f1 = bind(fac, 4);
  simple_future<double> f2 = fac8;
  simple_future<int>    f3 = fac_functor(6);

  std::cout << "a" << std::endl;
  BOOST_CHECK(f1() == 24);
  std::cout << "a" << std::endl;
  BOOST_CHECK(equal(f2(), 40320.0));
  std::cout << "a" << std::endl;
  BOOST_CHECK(f3() == 720);
  std::cout << "a" << std::endl;
  BOOST_CHECK(futurize(f3) == 720);

  return boost::exit_success;
}
