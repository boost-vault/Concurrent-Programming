//-----------------------------------------------------------------------------
// boost-libs futures/test/iterator_test.cpp source file
// See http://www.boost.org for updates, documentation, and revision history.
//-----------------------------------------------------------------------------
//
// Copyright (c) 2005
// Thorsten Schuett
//
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/test/minimal.hpp>
#include <boost/futures.hpp>

#include <map>

int fac(int n){
  if(n == 0)
    return 0;
  if(n == 1)
    return 1;
  return n * fac(n - 1);
}

int test_main(int , char* [])
{
  using namespace boost::futures;
  using namespace boost::fusion;
  using namespace boost;
  using namespace std;


  simple_future<int> f1 = bind(fac, 4);
  simple_future<int> f2 = bind(fac, 6);
  simple_future<int> f3 = bind(fac, 8);

  future<int>                   f_simple = f1;
  future<int>                   f_or     = f1 || f2 || f3;
  future<tuple<int, int, int> > f_and    = f1 && f2 && f3;
  int count = 0;

  for(future<int>::iterator it = f_simple.begin(); 
      f_simple.end() != it;
      ++it){
    count++;
    BOOST_CHECK(24 == *it);
  }
  BOOST_CHECK(1 == count);

  count = 0;
  int f_or_result = f_or();  
  map<int, bool> found;
  found[24]    = false;
  found[720]   = false;
  found[40320] = false;
  for(future<int>::iterator it = f_or.begin(); 
      f_or.end() != it;
      ++it){
    count++;
    BOOST_CHECK((24 == *it) || (720 == *it) || (40320 == *it));
    BOOST_CHECK(!found[*it]);
    found[*it] = true;
  }
  BOOST_CHECK(3 == count);
  BOOST_CHECK(f_or_result == f_or());

  count = 0;
  for(future<tuple<int, int, int> >::iterator it = f_and.begin(); 
      f_and.end() != it;
      ++it){
    count++;
    tuple<int, int, int> result = *it;
    BOOST_CHECK(   (get<0>(result) == 24)     
                && (get<1>(result) == 720)
                && (get<2>(result) == 40320));
  }
  BOOST_CHECK(1 == count);

  return boost::exit_success;
}
