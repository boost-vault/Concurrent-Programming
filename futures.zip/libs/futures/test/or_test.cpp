//-----------------------------------------------------------------------------
// boost-libs futures/test/or_test.cpp source file
// See http://www.boost.org for updates, documentation, and revision history.
//-----------------------------------------------------------------------------
//
// Copyright (c) 2005
// Thorsten Schuett
//
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cmath>
#include <boost/test/minimal.hpp>

#if BOOST_MSVC != 0
#pragma warning (disable: 4355)   // this is used in member initialiser list
#endif

#include <boost/bind.hpp>
#include <boost/futures.hpp>


int fac(int n)
{
    if(n == 0)
        return 0;
    if(n == 1)
        return 1;
    return n * fac(n - 1);
}

double fac8()
{
    return (double)fac(8);
}

struct fac_functor
{
    fac_functor(int n) : n(n) {}
    
    int operator()()
    {
        return fac(n);
    } 
    
    int n;
};

bool equal(double d1, double d2){
  return fabs(d1 - d2) < 0.001;
}

int test_main(int , char* [])
{
    using namespace boost::futures;
    using namespace boost;

    simple_future<int> f1 = bind(fac, 4);
    simple_future<double> f2 = fac8;
    simple_future<int> f3 = fac_functor(6);

    variant<int, double>          v1  = futurize(f1 || f2 || f3); 
    variant<int, double>          v2  = (f1 || f2 || f3)(); 
    future<variant<int, double> > f_1 = f1 || f2 || f3;
    future<int>                   f_2 = f1 || f3;   
    variant<int, double>          v3  = f_1();
 
    BOOST_CHECK((0 == v1.which() && boost::get<int>(v1) == 24) || 
                (0 == v1.which() && boost::get<int>(v1) == 720) ||
                (1 == v1.which() && equal(boost::get<double>(v1), 40320.0)));
        
    BOOST_CHECK((0 == v2.which() && boost::get<int>(v2) == 24) || 
                (0 == v2.which() && boost::get<int>(v2) == 720) ||
                (1 == v2.which() && equal(boost::get<double>(v2), 40320.0)));
        
    BOOST_CHECK((0 == v3.which() && boost::get<int>(v3) == 24) || 
                (0 == v3.which() && boost::get<int>(v3) == 720) ||
                (1 == v3.which() && equal(boost::get<double>(v3), 40320.0)));
        
    BOOST_CHECK(f_2() == 24 || f_2() == 720);

    return boost::exit_success;
}
