//-----------------------------------------------------------------------------
// boost-libs futures/test/and_test.cpp source file
// See http://www.boost.org for updates, documentation, and revision history.
//-----------------------------------------------------------------------------
//
// Copyright (c) 2005
// Thorsten Schuett
//
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/test/minimal.hpp>
#include <boost/futures.hpp>

int fac(int n){
  if(n == 0)
    return 0;
  if(n == 1)
    return 1;
  return n * fac(n - 1);
}

int test_main(int , char* [])
{
  using namespace boost::futures;
  using namespace boost::fusion;
  using namespace boost;


  simple_future<int> f1 = bind(fac, 4);
  simple_future<int> f2 = bind(fac, 8);
  tuple<int, int> t1 = futurize(f1 && f2);
  future<tuple<int, int> > f = f1 && f2;
  tuple<int, int> t2 = f();

  BOOST_CHECK(   (get<0>(t1) == 24)     
              && (get<1>(t1) == 40320));

  BOOST_CHECK(   (get<0>(t2) == 24)     
              && (get<1>(t2) == 40320));

  return boost::exit_success;
}
