//  helper class for future

//  Copyright (c) 2005 Thorsten Schuett. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_THREADED_FUTURE_HPP
#define BOOST_THREADED_FUTURE_HPP 1

#include <boost/assert.hpp>
#include <boost/bind.hpp>
#include <boost/function.hpp>
#include <boost/thread.hpp>

#include <boost/futures/futures_forward.hpp>
#include <boost/futures/detail/callback_registry.hpp>
#include <boost/futures/detail/callback_registry_helper.hpp>
#include <boost/futures/detail/value_holder.hpp>

///////////////////////////////////////////////////////////////////////////////
namespace boost {  namespace futures {  namespace detail { 

    ////////////////////////////////////////////////////////////////////////////
    template<typename T>
    class threaded_future
    {
    private:
        template<typename Func>
        class threaded_internal
        {
        public:
            threaded_internal(Func actor_, threaded_future<T> *outer_) 
              : actor(actor_), outer(outer_) {}
          
            void operator()()
            {
                outer->notify(actor());
            }
          
        private:
            Func actor;
            threaded_future<T> *outer;
        };
                                                                                        
    public:
        template<typename Func>
        threaded_future(Func actor) 
          : joining(false), thr(threaded_internal<Func>(actor, this))
        { }

        T get()
        {
          boost::mutex::scoped_lock scoped_lock(lock);

          if (!data.valid() && !joining)
          {
            joining = true;
            scoped_lock.unlock();
            thr.join();
            scoped_lock.lock();
            joining = false;
            condition.notify_all();
          }else if(joining)
          {
            while(joining) condition.wait(scoped_lock);
          }

          return data.get();
        }

        bool done()
        {
          boost::mutex::scoped_lock scoped_lock(lock);
          return data.valid();
        }

        template <typename Func>
        int done_or_register(Func const& setter)
        {
            boost::mutex::scoped_lock scoped_lock(lock);
            if (data.valid()) {
              setter(data.get());
              return -1;
            }
            int id = registry.register_callback(add_int(setter));

            return id;
        }

        template <typename Func>
        int get_next(Func const& setter, 
                     std::vector<bool> const& position)
        {
            BOOST_ASSERT(position.size() == 1);
            BOOST_ASSERT(position[0] == false);

            setter(get(), 0);

            return -1;
        }

        void unregister(int& id)
        {
            if (-1 != id) {
                boost::mutex::scoped_lock scoped_lock(lock);
                registry.unregister_callback(id);
                id = -1;            // reset the cookie
            }
        }

    private:
        void notify(T const& data_)
        {
          boost::mutex::scoped_lock scoped_lock(lock);
          data.set(data_);
          registry.notify_callbacks(data.get(), 0);
        }

        visitor_registry<T> registry;
        boost::mutex lock;
        value_holder<T> data;
        boost::condition condition;
        bool joining;
        boost::thread thr;
    };

///////////////////////////////////////////////////////////////////////////////
}}}  // namespace boost::futures::detail

#endif /* BOOST_THREADED_FUTURE_HPP */
