//  iterators for futures

//  Copyright (c) 2005 Thorsten Schuett. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_FUTURE_ITERATOR_HPP
#define BOOST_FUTURE_ITERATOR_HPP 1

#include <boost/iterator/iterator_facade.hpp>
#include <boost/thread.hpp>

#include <algorithm>
#include <vector>

///////////////////////////////////////////////////////////////////////////////
namespace boost {  namespace futures {  namespace detail { 

    ////////////////////////////////////////////////////////////////////////////

    template<typename FutureResult>
    class iterator_impl_base
    {
    public:

      virtual ~iterator_impl_base() {};
      virtual void increment() = 0;
      virtual FutureResult const& dereference() = 0;
      virtual bool equal(iterator_impl_base<FutureResult>* other) = 0;
    };

    template<typename Future, typename FutureResult>
    class iterator_impl 
      : public iterator_impl_base<FutureResult>
    {
    private:
      typedef iterator_impl<Future, FutureResult> self_type;

      template <typename RT>
      struct set_value
      {
        set_value(self_type& self) : self(self) {}
        
        void operator()(RT data_, int idx)
        {
          boost::mutex::scoped_lock scoped_lock(self.mutex);
          self.data = data_;
          self.current_idx = idx;
          self.notifying = true;
          self.valid = true;
          self.join_condition.notify_one();
        }
        
        self_type &self;
      };
 
    public:
      iterator_impl(Future const& f, std::vector<bool> const& position) 
        : f(f), position(position), valid(false), current_idx(-1) 
      {}

      virtual ~iterator_impl() {};

      void increment()
      {
        boost::mutex::scoped_lock scoped_lock(mutex);

        BOOST_ASSERT(!done());

        if(-1 == current_idx)
          join(scoped_lock);
        
        position[current_idx] = true;
        valid = false;
        if(done())
          return;
        join(scoped_lock);
        valid = true;
      }

      FutureResult const& dereference()
      {
        boost::mutex::scoped_lock scoped_lock(mutex);

        if(!valid)
          join(scoped_lock);
          
        return data;
      }

      bool equal(iterator_impl_base<FutureResult>* other_)
      {
        iterator_impl<Future, FutureResult>* other = 
          dynamic_cast<iterator_impl<Future, FutureResult> *>(other_);

        BOOST_ASSERT(NULL != other);

        return position == other->position;
      }
    private:

      /* PRE: lock is locked
       */
      void join(boost::mutex::scoped_lock &lock)
      {
        notifying = false;

        lock.unlock();
        f.derived().get_next(set_value<FutureResult>(*this), 
                             position);
        lock.lock();
        while(!notifying) join_condition.wait(lock);
      }

      bool done() const
      {
        for(std::vector<bool>::const_iterator it = position.begin();
            position.end() != it; ++it)
          if(!*it)
            return false;
        return true;
      }

      Future f;
      std::vector<bool> position;
      FutureResult data;
      bool valid;
      bool notifying;
      int current_idx;
      boost::mutex mutex;
      boost::condition join_condition;
    };


    template<typename FutureResult>
    class future_iterator : public boost::iterator_facade<
      future_iterator<FutureResult>,
      FutureResult const,
      boost::forward_traversal_tag>
    {
    public:
      future_iterator() {}

      future_iterator(iterator_impl_base<FutureResult> *position) 
        : position(position)
      {}
      
      virtual ~future_iterator() {};

    private:
      friend class boost::iterator_core_access;

      void increment() 
      { 
        position->increment(); 
      }

      bool equal(future_iterator const& other) const
      {
        return position->equal(other.position.get());
      }

      FutureResult const& dereference() const
      {
        return position->dereference();
      }

      boost::shared_ptr<iterator_impl_base<FutureResult> > position;
    };

    template<typename Future, typename FutureResult>
    struct iterator_factory{
      typedef future_iterator<FutureResult> iterator;
      iterator_factory(Future const& f) : f(f) 
      {
        std::fill_n(std::back_inserter(pos_begin), f.elements(), false);
        std::fill_n(std::back_inserter(pos_end), f.elements(), true);
      }

      iterator begin() const
      {
        return future_iterator<FutureResult>(
          new iterator_impl<Future, FutureResult>(f, pos_begin));
      }

      iterator end() const
      {
        return future_iterator<FutureResult>(
          new iterator_impl<Future, FutureResult>(f, pos_end));
      }

      Future f;
      std::vector<bool> pos_begin;
      std::vector<bool> pos_end;
    };

///////////////////////////////////////////////////////////////////////////////
}}}  // namespace boost::futures::detail

#endif /* BOOST_FUTURE_ITERATOR_HPP */
