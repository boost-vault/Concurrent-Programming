//  helper class for callback registry

//  Copyright (c) 2005 Thorsten Schuett. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_DETAIL_CALLBACK_REGISTRY_HELPER_HPP
#define BOOST_DETAIL_CALLBACK_REGISTRY_HELPER_HPP 1

#include <boost/function.hpp>

///////////////////////////////////////////////////////////////////////////////
namespace boost {  namespace futures {  namespace detail { 

    ////////////////////////////////////////////////////////////////////////////
    template<typename Result>
    class add_int_parameter
    {
    public:
      add_int_parameter(boost::function<void (Result)> const& func_)
        : func(func_) {}

      void operator()(Result r, int)
      {
        func(r);
      }
    private:
      boost::function<void (Result)> func;
    };

    template<typename Result>
    add_int_parameter<Result> add_int(boost::function<void (Result)> const& func)
    {
      return add_int_parameter<Result>(func);
    }
///////////////////////////////////////////////////////////////////////////////
}}}  // namespace boost::futures::detail

#endif /* BOOST_DETAIL_CALLBACK_REGISTRY_HELPER_HPP */
