//  helper class for threaded_or_future

//  Copyright (c) 2005 Thorsten Schuett. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_DETAIL_VALUE_HOLDER_HPP
#define BOOST_DETAIL_VALUE_HOLDER_HPP 1

#include <boost/function.hpp>

///////////////////////////////////////////////////////////////////////////////
namespace boost {  namespace futures {  namespace detail { 

  ////////////////////////////////////////////////////////////////////////////
  template<typename Result>
  class value_holder
  {
  public:
    value_holder() : is_valid(false) {}
    
    Result get() const
    {
      BOOST_ASSERT(is_valid);
      return value;
    }
    
    void set(Result value_)
    {
      BOOST_ASSERT(!is_valid);
      value = value_;
      is_valid = true;
    }

    bool valid() const
    {
      return is_valid;
    }
  private:
    Result value;
    bool is_valid;
  };

///////////////////////////////////////////////////////////////////////////////
}}}  // namespace boost::futures::detail

#endif /* BOOST_DETAIL_VALUE_HOLDER_HPP */
