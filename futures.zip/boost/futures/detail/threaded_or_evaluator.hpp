//  helper class for composite_future<or_op, T>

//  Copyright (c) 2005 Thorsten Schuett. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef FUTURES_DETAIL_THREADED_OR_EVALUATOR_HPP
#define FUTURES_DETAIL_THREADED_OR_EVALUATOR_HPP 1

#include <boost/bind.hpp>
#include <boost/thread.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/type_traits/remove_reference.hpp>

#include <boost/spirit/fusion/iterator/equal_to.hpp>
#include <boost/spirit/fusion/iterator/next.hpp>
#include <boost/spirit/fusion/iterator/deref.hpp>
#include <boost/spirit/fusion/iterator/value_of.hpp>
#include <boost/spirit/fusion/algorithm/for_each.hpp>

#include <boost/futures/future.hpp>
#include <boost/futures/detail/value_holder.hpp>

////////////////////////////////////////////////////////////////////////////////
namespace boost {  namespace futures {  namespace detail { 
  
  ////////////////////////////////////////////////////////////////////////////
  template <typename Tuple, typename Result>
  class threaded_evaluator<or_op, Tuple, Result>
  {
    typedef threaded_evaluator<or_op, Tuple, Result> self_type;
    typedef boost::function<void (Result, int)> callback_type;
    
  public:
    threaded_evaluator(Tuple operands_)
      : operands(operands_), joining(false)
    {}
    
    ~threaded_evaluator()
    {
      cleanup();
    }

    Result get_value()
    {
      boost::recursive_mutex::scoped_lock scoped_lock(lock);
      
      if (data.valid())
        return data.get();
      
      std::vector<bool> position;
      std::fill_n(std::back_inserter(position), elements(), false);
      
      join(position);
      
      if (data.valid()){
        // one of the referenced futures has joined in the meantime
        cleanup();
        return data.get();
      }
      
      // none of the referenced futures has joined yet, 
      // wait for the first one
      while(!notifying) joined_condition.wait(scoped_lock);

      joining = false;
      
      cleanup();
      return data.get();
    }
    
    bool done()
    {
      boost::recursive_mutex::scoped_lock scoped_lock(lock);
      return data.valid();
    }
    
    void get_next(boost::function<void (Result, int)> callback,
                 std::vector<bool> const& position)
    {
      BOOST_ASSERT(position.size() == elements());
      
      boost::recursive_mutex::scoped_lock scoped_lock(lock);

      registry_for_iterators.register_callback(callback);
      done_or_register(
                       fusion::begin(operands), fusion::end(operands), 0,
                       position,
                       fusion::meta::equal_to<
                       BOOST_DEDUCED_TYPENAME fusion::meta::begin<Tuple>::type,
                       BOOST_DEDUCED_TYPENAME fusion::meta::end<Tuple>::type
                       >()
        );
    }
    
    void unregister(int& id)
    {
      if (-1 != id) {
        boost::recursive_mutex::scoped_lock scoped_lock(lock);

        registry_for_iterators.unregister_callback(id);
        id = -1;            // reset the cookie
      }
    }
  
    size_t elements() const
    {
      return Tuple::size::value;
    }
      
  private:
    void join(std::vector<bool> const& position)
    {
      notifying = false;
      //if we are the first one to join
      if(!joining){
        joining = true;
        done_or_register(
                         fusion::begin(operands), fusion::end(operands), 0,
                         position,
                         fusion::meta::equal_to<
                         BOOST_DEDUCED_TYPENAME fusion::meta::begin<Tuple>::type,
                         BOOST_DEDUCED_TYPENAME fusion::meta::end<Tuple>::type
                         >()
          );
      }
    }
      
    //  register our callback with all futures referenced by this composite
    struct set_value
    {
      set_value(self_type& self) : self(self) {}
        
      void operator()(Result data_, int idx)
      {
        boost::recursive_mutex::scoped_lock scoped_lock(self.lock);
        if(!self.data.valid())
          self.data.set(data_);
        
        self.registry_for_iterators.notify_callbacks(data_, idx);
        self.notifying = true;
        self.cleanup(idx);
        self.joined_condition.notify_all();
      }
        
      self_type &self;
    };
      
    template <typename First, typename Last>
    bool done_or_register(First const&, Last const&, int idx, 
                          std::vector<bool> const& position, 
                          mpl::true_)
    {
      return false;
    }
        
    /*
     * returns whether an item was found
     */
    template <typename First, typename Last>
    bool done_or_register(First first, Last last, int idx,  
                          std::vector<bool> const& position, 
                          mpl::false_)
    {
      typedef typename fusion::meta::value_of<First>::type element_type;
      typedef typename element_type::first_type::result_type first_type;
      
      if(!position[idx] && (-1 == (*first).second))
      {
        int id = (*first).first.done_or_register(
          boost::bind<void>(set_value(*this), _1, idx));
        if (-1 == id)
          return true;
        
        (*first).second = id;
      }
      
      return done_or_register(fusion::next(first), last, idx + 1,
        position,
        fusion::meta::equal_to<
          BOOST_DEDUCED_TYPENAME fusion::meta::next<First>::type, 
          Last
        >());
    }
  
    //  cleanup the registration of our callback function with all referenced 
    //  futures        
    struct cleanup_functor
    {
      template <typename Value>
      void operator()(Value& v) const
      {
        v.first.unregister(v.second);
      }
    };
  
    //  cleanup the registration of our callback function with all referenced 
    //  futures        
    class cleanup_functor_idx
    {
      mutable int idx;
    public:
      cleanup_functor_idx(int idx) : idx(idx) {};

      template <typename Value>
      void operator()(Value& v) const
      {
        if(0 == idx){
          //v.first.unregister(v.second);
          v.second = -1;
        }
        idx--;
      }      
    };
  
    void cleanup()
    {
      fusion::for_each(operands, cleanup_functor());
    }

    void cleanup(int idx)
    {
      fusion::for_each(operands, cleanup_functor_idx(idx));
    }

    visitor_registry<Result> registry_for_iterators;
    value_holder<Result> data;
    Tuple operands;
    bool notifying;
    bool joining;
    boost::condition joined_condition;
    boost::recursive_mutex lock;
  };

///////////////////////////////////////////////////////////////////////////////
}}}  // namespace boost::futures::detail

#endif /* FUTURES_DETAIL_THREADED_OR_EVALUATOR_HPP */
