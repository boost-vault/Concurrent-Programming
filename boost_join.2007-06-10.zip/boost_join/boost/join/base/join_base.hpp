//
// boost/join/actor.hpp
//
// Copyright (c) 2007 Yigong Liu (yigongliu at gmail dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef BOOST_JOIN_BASE_HPP
#define BOOST_JOIN_BASE_HPP

#include <string>
#include <vector>
#include <iostream>
#include <boost/thread.hpp>
#include <boost/function.hpp>
#include <boost/utility.hpp>
#include <boost/join/base/utils.hpp>

namespace boost {
  namespace join {

    //a container for exceptions that is thrown by "raise" inside chord body
    class chord_exception_base
    {
    public:
      virtual ~chord_exception_base()
      {
      }

      virtual void raise() const = 0;
    };

    template <typename E>
    class chord_exception_t :
      public chord_exception_base
    {
    public:
      template <typename A> 
      chord_exception_t(A const & a)
	: e_(a)
      {
      }

      virtual void raise() const
      {
	throw e_;
      }

    private:
      E e_;
    };

    class chord_base;
    class port;

    class actor_base : private boost::noncopyable {
    public:
      typedef boost::function0<void> callable;
      typedef chord_exception_base chord_exception;
      const char * name_;
      logger log;
      boost::mutex mutex_; // protects actor global status including ports and chords
      actor_base(const char *n) : name_(n), log(n) {}
      virtual ~actor_base() {}
      virtual bool port_invoked(int ind) = 0;
      virtual void notify_other_synch_calls_finish(chord_base *c, port *p, boost::shared_ptr<chord_exception_base> ep) = 0;
      //a template method for chord body to "raise" application exceptions
      template <typename E>
      void raise(E e) const {
	throw new chord_exception_t<E>(e);
      }
    };

    class chord_base {
    public:
      int num_synch_ports_;
      chord_base (int n) : num_synch_ports_(n) {};
    };      

    class port {
    public:
      enum port_type {
	async,
	synch
      } ;
      port_type type_;
      actor_base * actor_; //pointer to owning actor
      int index_;  //my index in actor
      //the following are information used by actor for chords matching/firing
      std::vector<std::vector<chord_base*> > chords_; //chords this port participates in
      unsigned int num_pending_; //pending calls/msgs at this port
      std::vector<int> last_chord_fired_; //for roundrobin dispatching
      bool bound_;

      port(port_type t=async) : 
	type_(t), actor_(NULL), index_(-1), num_pending_(0), bound_(false) {
	last_chord_fired_.push_back(-1);
	chords_.push_back(std::vector<chord_base*>());
      }
      virtual ~port() {}

      //when detached from actor, need reset
      virtual void reset(void) {
	actor_ = NULL;
	index_ = -1;
	//chords_.clear();
	num_pending_ = 0;
	//last_chord_fired_[ = -1;
      }

      virtual void put(void) {}

      bool test_chord_fire(void) {
	return actor_->port_invoked(index_);
      }

    };

  }
}

#endif
