//
// boost/join/actor.hpp
//
// Copyright (c) 2007 Yigong Liu (yigongliu at gmail dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef BOOST_JOIN_UTILS_HPP
#define BOOST_JOIN_UTILS_HPP

#include <iostream>
#include <string>
#include <boost/thread.hpp>
#include <sstream>

namespace boost {
  namespace join {

    //since in Windows, std::cout is not thread-safe, so define a simple thread-safe logger here
    class logger : public std::stringstream {
    public:
      const char *name_;
#if defined(BOOST_WINDOWS) || defined(__CYGWIN__)
      static boost::mutex mutex_; 
#endif

      logger(const char *n = NULL) : name_(n) {
      }

      void msg(std::string str) {
	if (name_ == NULL) return;
#if defined(BOOST_WINDOWS) || defined(__CYGWIN__)
	boost::mutex::scoped_lock lock(mutex_);
#endif
	std::cout << "[" << name_ << "] : " << str << std::endl;
      }
      std::stringstream & stream(void) {
#if defined(BOOST_WINDOWS) || defined(__CYGWIN__)
	boost::mutex::scoped_lock lock(mutex_);
	return *(new logger(name_));
#else
	return *this;
#endif
      }
      void flush(void) {
#if defined(BOOST_WINDOWS) || defined(__CYGWIN__)
	boost::mutex::scoped_lock lock(mutex_);
#endif
	if(name_ != NULL)
	  std::cout << "[" << name_ << "] " << this->str();
	this->str("");
      }
      void flushl(void) {
#if defined(BOOST_WINDOWS) || defined(__CYGWIN__)
	boost::mutex::scoped_lock lock(mutex_);
#endif
	if(name_ != NULL)
	  std::cout << "[" << name_ << "] " << this->str() << std::endl;
	this->str("");
      }
      typedef void func(logger &l);
      static void end(logger &l) { 
	l.flush(); 
#if defined(BOOST_WINDOWS) || defined(__CYGWIN__)
	delete &l;
#endif
      }
      static void endl(logger &l) { 
	l.flushl(); 
#if defined(BOOST_WINDOWS) || defined(__CYGWIN__)
	delete &l;
#endif
      }
    };
    std::ostream &operator << (std::ostream &os, logger::func *f) {
      f((logger&)os);
      return os;
    }
#if defined(BOOST_WINDOWS) || defined(__CYGWIN__)
    boost::mutex logger::mutex_;
#endif
  }
}

#endif

