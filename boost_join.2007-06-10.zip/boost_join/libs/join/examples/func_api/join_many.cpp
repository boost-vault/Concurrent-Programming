//
// join_many.cpp
//
// Copyright (c) 2007 Yigong Liu (yigongliu at gmail dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/join/join.hpp>
#include <iostream>
#include <vector>

using namespace std;
using namespace boost::join;

logger log1("log");

// join multiple input streams into one output stream
template <typename T>
class join_many : public actor<> {
public:
  vector<async<void(T)> > inputs;
  synch<vector<T>(void)> output;
  join_many(int n) : actor<>(), inputs(n) {
    chord(output, inputs, &join_many::chord_body);
  }
  void chord_body(synch_o<vector<T>(void)> out, vector<async_o<void(T)> > in) {
    vector<T> vt;
    for(size_t i=0; i<in.size(); i++)
      vt.push_back(in[i].arg1);
    out.reply(vt);
  }
};

void thread_sleep(int sec) {
    boost::xtime xt;
    boost::xtime_get(&xt, boost::TIME_UTC);
    xt.sec += sec;
    boost::thread::sleep(xt);
}

class Demo : public actor<> {
public:
  enum {
    num_test = 5
  };
  join_many<int> merger;
  async<void(int)> inputer;
  void wait(void) {
    vector<int> results;
    for(int i=0; i<num_test; i++) {
      results = merger.output();
      log1.stream() << "output" << i << " = " << logger::end;
      for(size_t j=0;j<results.size();j++) 
	log1.stream() << results[j] << " " << logger::end;
      log1.stream() << logger::endl;
    }
  }
  Demo(executor *e, int n) : actor<>(e), merger(n) {
    chord(inputer, &Demo::chord_body);
    //spawn multiple concurrent test streams
    for(int i=0; i<n; i++)
      inputer(i);
  }
  void chord_body(async_o<void(int)> p) {
    int start = p.arg1*num_test;
    int end = start+num_test;
    for(int i=start; i<end; i++) {
      log1.stream() << "inputer[" << p.arg1 << "] sends [" << i << "] and wait..." << logger::endl;
      merger.inputs[p.arg1](i);
      thread_sleep((p.arg1+1)%3);
    }
  }
};

int main(int argc, char **argv) {
  executor exec(4);  //spawn 4 threads for executor thread pool
  Demo demo(&exec.execute,4);
  log1.msg("main thread starts waiting...");
  demo.wait();
  log1.msg("main thread finish waiting...");
  exec.shutdown();
  return 0;
}
