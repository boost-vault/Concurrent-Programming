//  (C) Copyright Giovanni P. Deretta 2005. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef GDP_CONTEXT_CONDITION_HPP_21122005
#define GDP_CONTEXT_CONDITION_HPP_21122005
#include <boost/utility.hpp>
namespace  continuation {

  enum wait_mode {wait_all, wait_any};

  template<typename T>
  class condition_base;

  template<typename SchedulerType>
  class condition_node_base :boost::noncopyable{

  public:
    typedef SchedulerType scheduler_type;
    typedef typename scheduler_type::context_ptr context_ptr;
    typedef condition_base<scheduler_type> condition_type;
    friend class condition_type;
    typedef condition_node_base<scheduler_type> type;

    explicit
    condition_node_base(type& parent, wait_mode mode = wait_all) :
      m_parent(&parent),
      m_mode(mode),
      m_counter(0),
      m_ctx(m_parent->m_ctx),
      m_scheduler(m_parent->m_scheduler) {
      m_parent->inc();
    }

    explicit
    condition_node_base(scheduler_type& sched, wait_mode mode = wait_all) :
      m_parent(0),
      m_mode(mode),
      m_counter(0),
      m_ctx(sched.front()),
      m_scheduler(&sched){}
 
    condition_type 
    leaf();

    //m_counter MUST be greater than zero upon entering this
    //function, that is, there must be some condition
    //we are waiting for.
    void wait() {
      unsigned int old_counter = m_counter;
      BOOST_ASSERT(m_counter);
      if(m_counter) {
	type* tmp =  m_parent;
	m_parent = 0;
	m_scheduler->wait();

	//check for spurious wakeups
	BOOST_ASSERT(m_counter == 0 || m_mode == wait_any);
	BOOST_ASSERT(old_counter > m_counter);

	m_parent = tmp;
	if(m_parent) m_parent->signal();
      }

    }

    int pending() const {
      return m_counter;
    }

    void join_all() {
      if(pending()) {
	wait_mode old_mode = m_mode; 
	m_mode = wait_all;
	wait();
	m_mode = old_mode;
      }
      BOOST_ASSERT(!pending());
    }

  private:
    void inc() {
      m_counter++;
    }

    void signal (){
      BOOST_ASSERT(m_counter > 0);
      BOOST_ASSERT(m_scheduler);
      m_counter --;
      if(m_counter == 0 || m_mode == wait_any) {
	if(m_parent) {
	  m_parent->signal();
	} else {
	  m_scheduler->signal(m_ctx);
	}
      }
    }
   
    type * m_parent;
    wait_mode m_mode;
    unsigned int m_counter;
    context_ptr m_ctx;
    scheduler_type * m_scheduler;
  };

  template<typename SchedulerType>
  class condition_base {
  public:
    typedef SchedulerType scheduler_type;
    typedef condition_base<scheduler_type> type;
    typedef condition_node_base<scheduler_type> condition_node;
    typedef typename condition_node::context_ptr context_ptr;

    explicit
    condition_base(condition_node& parent) :
      m_parent (&parent),
      m_ctx (m_parent->m_ctx),
      m_scheduler(m_parent->m_scheduler) {
      m_parent->inc();
    }

    condition_base(scheduler_type& scheduler) :
      m_parent(0),
      m_ctx(scheduler->front()),
      m_scheduler(&scheduler) {}

    condition_base(const type& rhs):
      m_parent(rhs.m_parent),
      m_ctx(rhs.m_ctx),
      m_scheduler(rhs.m_scheduler){}
  
    void signal () {
      if(m_parent) {
	m_parent->signal();
      } else {
	m_scheduler->signal(m_ctx);
      }
    }

    void wait() {
      condition_node* tmp =  0;
      std::swap(m_parent, tmp);
      m_scheduler->wait();
      std::swap(m_parent, tmp);
      if(m_parent) m_parent->signal();
    }
  
  private:
    condition_node * m_parent;
    context_ptr m_ctx;
    scheduler_type * m_scheduler;
  };

  template<typename SchedulerType>
  typename condition_node_base<SchedulerType>::condition_type
  condition_node_base<SchedulerType>::leaf() {
    return condition_type(*this);
  }


}/* namespace continuation */
#endif
