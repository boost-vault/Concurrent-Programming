//  (C) Copyright Giovanni P. Deretta 2005. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef GDP_CONTINUATION_SCHEDULER_HPP_23122005
#define GDP_CONTINUATION_SCHEDULER_HPP_23122005
#include <algorithm>
#include <boost/bind.hpp>
#include <boost/utility.hpp>
#include <boost/intrusive_ptr.hpp>
#include <continuation/condition.hpp>
#include <continuation/context_base.hpp>
namespace continuation {

  namespace detail {
    /*
     * This class applies type erasure to the actual
     * functor type. 
     * @note It works as a virtual base class, but
     * it does not use the C++ dynamic polimorphism system (virtual functions,
     * virtual destructor and virtual inheritance).
     * boost::function could be used, but it doesa
     * dynamic allocation of the functor internally. Instaces of this class  are
     * dynamically allocated this class anyway, we can save an allocation. 
     * Also boost function uses trampolines
     * and indirect calls. These things are done by the context switching
     * routines anyway and are not needed. 
     * @note Instances of this class are not directly allocated, 
     * instead context_mixins are allocated and assigned to intrusive_ptr
     * to this class type.
     * @note Because intrusive_ptr does not remember the type with wich it
     * was initialized (while shared_ptr does), we need to keep a deleter in
     * this class.
     * @note As a final benefit, any flag that does not belong to the context
     * proper (because of encapsulation and separation of responsability 
     * concerns), can be saffely put here.
     */
    template<typename ContextImpl>
    class context_chainer {
    public:
      typedef ContextImpl context_impl;
      typedef context_chainer<context_impl> type;
      typedef boost::intrusive_ptr<type> context_ptr;
      typedef void deleter_type(const type*);

      template<typename DerivedCtx>
      context_chainer(DerivedCtx * rhs) :
	m_ctx(rhs),
	m_counter(0),
	m_next(0),
	m_deleter(&context_chainer::deleter<DerivedCtx>),
	m_inserted(false) {}
    
      friend
      void intrusive_ptr_add_ref(type * ctx) {
	ctx->acquire();
      }
      
      friend
      void intrusive_ptr_release(type * ctx) {
	ctx->release();
      }
      
      bool unique() const {
	return !count();
      }

      unsigned int count() const {
	return m_counter;
      }

      operator context_impl&() {
	return *m_ctx;
      }

      operator const context_impl&() const {
	return *m_ctx;
      }
      
      context_ptr next() {
	return m_next;
      }
     
      void next(context_ptr next) {
	BOOST_ASSERT(!next || (next && next->inserted()));
	m_next = next;
      }
      
      bool inserted() const {
	return m_inserted;
      }

      void inserted(bool newflag) {
	BOOST_ASSERT(newflag != m_inserted);
	m_inserted = newflag;
      }

    private: 
      template<typename ActualCtx>
      static void deleter (const type* ctx){
	delete static_cast<ActualCtx*>(const_cast<type*>(ctx));
      }

      void acquire() {
	m_counter ++;
      }
      
      void release() const {
	BOOST_ASSERT(m_counter);
	m_counter --;
	if(m_counter == 0) {
	  m_deleter(this);
	}
      }
            
      context_impl * m_ctx;
      mutable size_t m_counter;
      context_ptr m_next;
      deleter_type * m_deleter;
      bool m_inserted;
    };

    template<typename ContextImpl, typename Functor>
    class context_mixin :
      public context_base<ContextImpl, Functor>, 
      public context_chainer<ContextImpl>
    {
    public:
      typedef ContextImpl context_impl;

      typedef context_base<context_impl, Functor> context_base;
      typedef context_chainer<context_impl> context_chainer;
    
      context_mixin(Functor fun) :
	context_base(fun),
	context_chainer(this) {}      
    };
  }

  namespace detail {
    template <typename Condition> 
    class callback_0 {
    public:
      typedef void result_type;

      callback_0(Condition cond) :
	m_condition(cond) {}
	
      void operator()() {
	m_condition.signal();
      }
    private:
      Condition m_condition;
    };


    template <typename Condition, typename Arg0> 
    class callback_1 {
    public:
      typedef void result_type;
      typedef Arg0 arg0_type;

      callback_1(Condition cond, arg0_type& arg0) :
	m_condition(cond),
	m_arg0(arg0) {}
	
      void operator()(arg0_type arg0) {
	m_arg0 = arg0;
	m_condition.signal();
      }
    private:
      Condition m_condition;
      arg0_type & m_arg0;
    };

    template <typename Condition, typename Arg0, typename Arg1> 
    class callback_2 {
    public:
      typedef void result_type;
      typedef Arg0 arg0_type;
      typedef Arg1 arg1_type;

      callback_2(Condition cond, arg0_type& arg0, arg1_type& arg1) :
	m_condition(cond),
	m_arg0(arg0),
	m_arg1(arg1) {}
	
      void operator()(arg0_type arg0, arg1_type arg1) {
	m_arg0 = arg0;
	m_arg1 = arg1;
	m_condition.signal();
      }
    private:
      Condition m_condition;
      arg0_type & m_arg0;
      arg1_type & m_arg1;
    };
  }/* namespace detail */

  template<typename ContextImpl, typename DemuxerType>
  class scheduler_base { 
  public:
    typedef DemuxerType demuxer_type;
    typedef ContextImpl context_impl;
    typedef detail::context_chainer<context_impl> context_type;
    typedef scheduler_base<context_impl,demuxer_type> type;
    typedef typename context_type::context_ptr context_ptr;
    typedef condition_base<type> conditon_type;
    typedef condition_node_base<type> condition_node_type;
    typedef typename condition_node_type::condition_type condition_type;

    scheduler_base(demuxer_type& demux) : 
      m_main_ctx(typename context_impl::incomplete_context_token()),
      m_first (0),
      m_last (0),
      m_demuxer (demux),
      m_posted (false),
      m_in_coroutine (false) {}
      
    /**
     * Return true if a coroutine is running.
     */
    bool in_coroutine() const {
      return m_in_coroutine;
    }
      
    void wait() {
      run_next();
    }

    /**
     * Put the current context at the end of the list.
     * @note Post a delayed push_back in the demuxer
     * in order to give other callbacks a chance
     * to run.
     * @note Can be called only from a coroutine context.
     */
    void yeld() {
      BOOST_ASSERT(in_coroutine());
      BOOST_ASSERT(!empty());
      context_ptr current = front();
      signal(current);
      run_next();
    }

    template<typename Functor>
    void
    post(Functor fun) {
      signal(alloc_context(make_adaptor(fun)));
    }

    /**
     * Adds a context at the end of the list.
     * and posts a delayed call to run_scheduler.
     * @note If signal is called from a coroutine context,
     * the push back call is delayed too.
     */     
    void signal(context_ptr ctx) {
      if(ctx->inserted()) return;
      if(in_coroutine()) {
	m_demuxer.post(boost::bind(&type::signal, this, ctx));
      } else {
	push_back_private(ctx);
	post_run();
      }
    }
      
    /**
     * Post a delayed call to run_scheduler function in the demuxer
     * if not already pending and list not empty.
     */
    void post_run() {
      if(!posted()) {
	if(!empty()) {
	  m_demuxer.post(boost::bind(&type::run_scheduler, this));
	  set_post();
	}
      }
    }

    /**
     * Save context, remove current coroutine from ready list and
     * run next scheduled coroutine
     * @note can be called only from coroutine context.
     */
    void run_next() {
      BOOST_ASSERT(in_coroutine());
      
      context_ptr current = pop();
      BOOST_ASSERT(!current->unique());
      if(!empty()) {
	BOOST_ASSERT(front()->inserted());
	swap_context(*current, *front());
      } else {
	swap_context(*current, m_main_ctx);
      }
    }

    /**
     * Run next scheduled coroutine, and removes current
     * coroutine from ready list.
     * @can be called only from coroutine context.
     */
    void run_next_discard() {
      BOOST_ASSERT(in_coroutine());
      pop();
      if(!empty()) {
	BOOST_ASSERT(front()->inserted());
	set_context(*front());
      } else 
	set_context(m_main_ctx);
    }
  
    /**
     * Returns a pointer to current coroutine.
     */
    context_ptr front() {
      BOOST_ASSERT(m_first != 0);
      return m_first;
    }

    /**
     * Higher order function that returns a functor that when
     * called reschedules the current function.
     * @note If the functor is called when the function is running, 
     */
    
    detail::callback_0<condition_type>
    current_continuation() {
      return detail::callback_0<condition_type>(condition_type(*this));
    }
    
    template<typename Arg0>
    detail::callback_1<condition_type, Arg0>
    current_continuation(Arg0& arg0) {
      return detail::callback_1<condition_type, Arg0>(condition_type(*this), arg0);
    }
    
    template<typename Arg0, typename Arg1>
    detail::callback_2<condition_type, Arg0, Arg1>
    current_continuation(Arg0& arg0, Arg1& arg1) {
      return detail::callback_2<condition_type, Arg0, Arg1>(condition_type(), arg0, arg1);
    }
    
    detail::callback_0<condition_type>
    current_continuation(condition_type cond) {
      return detail::callback_0<condition_type>(cond);
    }
    
    template<typename Arg0>
    detail::callback_1<condition_type, Arg0>
    current_continuation(condition_type cond, Arg0& arg0) {
      return detail::callback_1<condition_type, Arg0>(cond, arg0);
    }
    
    template<typename Arg0, typename Arg1>
    detail::callback_2<condition_type, Arg0, Arg1>
    current_continuation(condition_type cond, Arg0& arg0, Arg1& arg1) {
      return detail::callback_2<condition_type, Arg0, Arg1>(cond, arg0, arg1);
    }
    
  private:
    /**
     * Adds a context at the end of the list.
     */
    void 
    push_back_private(context_ptr ctx) {
      BOOST_ASSERT(!ctx->inserted());
      ctx->inserted(true);
      if(m_first) {
	BOOST_ASSERT(m_last != 0);
	BOOST_ASSERT(m_last != ctx);
	m_last->next(ctx);
	m_last = m_last->next();
      } else {
	BOOST_ASSERT(m_last == 0);
	m_first = m_last = ctx;
      }
    }


    template<typename Functor>
    static inline 
    context_ptr 
    alloc_context(Functor fun) {
      return new detail::context_mixin<context_impl, Functor>(fun);
    }

    template<typename Functor>
    class adaptor {
      Functor m_fun;
      type * m_scheduler;

      
    public:
      adaptor(type *self, Functor fun) :
	m_fun(fun),
	m_scheduler(self) {}
	
      void operator()() {
	try {
	  m_fun();
	} catch(const exit_exception&) {}
	m_scheduler->run_next_discard();
      }
    };
      
    template<typename Functor>
    adaptor<Functor>
    make_adaptor(const Functor& f) {
      return adaptor<Functor>(this, f);
    }

    /**
     * Run all ready coroutines.
     * @note Can be called only from main context
     */
    void run_scheduler() {
      BOOST_ASSERT(!in_coroutine());
      BOOST_ASSERT(!empty());
      unset_post();
      m_in_coroutine = true;
      BOOST_ASSERT(front()->inserted());
      swap_context(m_main_ctx, *front());
      m_in_coroutine = false;
      post_run();
    }

    void unset_post() {
      m_posted = false;
    }

    void set_post() {
      m_posted = true;
    }

    bool posted() const {
      return m_posted;
    }

    /**
     * Removes current coroutine from list.
     */
    context_ptr  
    pop () {
      BOOST_ASSERT(m_first != 0);
      context_ptr ret = m_first;
      m_first = m_first->next();
      if(m_last == ret)
	m_last = m_first;
      ret->next(0);
      ret->inserted(false);
      return ret;
    }

    bool 
    empty() const {
      return !m_first;
    }

    context_impl m_main_ctx;
    context_ptr m_first;
    context_ptr m_last;
    demuxer_type& m_demuxer;
    bool m_posted;
    bool m_in_coroutine;
  };
  
  /**
   * Terminates current process. Waits for all pending operations
   * to complete.  Correctly destorys all objects in the stack.
   * @note Terminates by throwing a exit_exception. 
   */
  inline void
  exit() {
    throw exit_exception();
  }
} /* namespace continuation */

#endif
