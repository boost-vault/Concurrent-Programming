//  (C) Copyright Giovanni P. Deretta 2005. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#include <boost/asio.hpp>
#include <boost/lexical_cast.hpp>
#include <continuation/scheduler.hpp>

boost::asio::demuxer demuxer;
continuation::scheduler scheduler(demuxer);

void yelder (int count) {
  while(count--) {
    scheduler.yeld();
  }
}

int main(int argc, char**argv) {
  int count = (argc >= 2? boost::lexical_cast<int>(argv[1]): 100);
  int count_2 = (argc == 3? boost::lexical_cast<int>(argv[2]): 1);
  while(count_2--) 
    scheduler.post(boost::bind(yelder, count)); 
  demuxer.run(); 
} 
 
 
