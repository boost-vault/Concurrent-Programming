//  (C) Copyright Giovanni P. Deretta 2005. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef GPD_CONTEXT_CONTEXT_POSIX_HPP_21122005
#define GPD_CONTEXT_CONTEXT_POSIX_HPP_21122005
#include <ucontext.h>
#include <continuation/ctx.hpp>
#include <sys/mman.h>
#include <boost/optional.hpp>
#include <continuation/exception.hpp>


namespace continuation {
  namespace posix {
    namespace detail {
      /**
       * Stack allocator and deleter functions.
       * Better implementations are possible using
       * mmap (might be required on some systems) and/or
       * using a pooling allocator.
       */
      inline
      void* alloc_stack(size_t size) {
	return new char[size];
      }

      inline
      void free_stack(void* stack, size_t size) {
	delete [] (char*)stack;
      }

      inline 
      void * 
      alloc_stack_mmap(size_t size) {
	void * stack = ::mmap(NULL,
	 		8192*2,
			PROT_EXEC|PROT_READ|PROT_WRITE,
			MAP_PRIVATE|MAP_ANONYMOUS,
			-1,
			0
			);
	if(stack == MAP_FAILED) {
	  std::cerr <<strerror(errno)<<"\n";
	  abort();
	}
	return stack;
      }

      inline
      void free_stack_mmap(void* stack, size_t size) {
	::munmap(stack, size);
      }

      /**
       * The splitter is needed for 64 bit systems. 
       * @note The current implementation does NOT use
       * (for debug reasons).
       * Thus it is not 64 bit clean.
       * Use it for 64 bits systems.
       */
      template<typename T>
      union splitter {
	int int_[2];
	T* ptr;
	splitter(int first, int second) {
	  int_[0] = first;
	  int_[1] = second;
	}

	int first() {
	  return int_[0];
	}

	int second() {
	  return int_[1];
	}

	splitter(T* ptr) :ptr(ptr) {}

	void operator()() {
	  (*ptr)();
	}
      };
#if 0
      template<typename T>
      inline
      void
      trampoline(int first, int second) {
	splitter<T> split(first, second);
	split();
      }
#endif
      template<typename T>
      inline
      void
      trampoline(T * fun) {
	(*fun)();
      }

    }
    /**
     * Posix implementation for the context_impl class.
     * @note context_impl is not required to be consistent
     * if not initialized with a functor.
     * If not initialized it can only be swapped out, not in 
     * (at that point it will be initialized).
     */


    class context_impl {
    public:
      class incomplete_context_token {};
      
      enum {default_stack_size = 8192};
      
      context_impl(incomplete_context_token) :
	m_stack(0),
	m_good(false){}

      template<typename Functor>
      context_impl(Functor& cb, size_t stack_size = default_stack_size) :
      m_stack(detail::alloc_stack(stack_size)),
      m_good(true) {
#ifdef _CONTEXT_FAST_SWAP
	int error = ::my_getcontext(&m_ctx);
#else
	int error = ::getcontext(&m_ctx);
#endif
	BOOST_ASSERT(error == 0);
	m_ctx.uc_stack.ss_sp = m_stack;
	m_ctx.uc_stack.ss_size = stack_size;
	BOOST_ASSERT(m_stack);
	m_ctx.uc_link = 0;
	detail::splitter<Functor> split(&cb);
	typedef void cb_type(Functor*);
	typedef void (*ctx_main)();
	cb_type * cb_ptr = (detail::trampoline<Functor>); 
	::makecontext(&m_ctx,
		      (ctx_main)(cb_ptr), 
		      1,
		      &cb);
      }
      
      ~context_impl() {
	if(m_stack)
	  detail::free_stack(m_stack, m_ctx.uc_stack.ss_size);
      }

      /**
       * Free function. Saves the current context in @p from
       * and restores the context in @p to.
       * @note This function is usually found by ADL (this is stupid, just
       * make'em members or static members).
       */     
      friend 
      void 
      swap_context(context_impl& from, const context_impl& to) {
	BOOST_ASSERT(to.m_good);
	from.m_good = true;
	//	GDP_PREFETCH_STACK_AT(to.m_stack);
#ifdef _CONTEXT_FAST_SWAP
	int  error = ::my_swapcontext(&from.m_ctx, &to.m_ctx);
#else
	int  error = ::swapcontext(&from.m_ctx, &to.m_ctx); 
#endif
	if(error != 0) {
	  to.m_good = false;
	  from.m_good = false;
	  throw swap_error();
	}
      }

      friend 
      void
      set_context(const context_impl& to) {
	BOOST_ASSERT(to.m_good);
	GDP_PREFETCH_STACK_AT(to.m_stack);
#ifdef _CONTEXT_FAST_SWAP
	int error = ::my_setcontext(&to.m_ctx);
#else
	int error = ::setcontext(&to.m_ctx);
#endif
	BOOST_ASSERT(error);
	if(error != 0) {
	  to.m_good = false;
	  throw swap_error();
	}
      }

      friend 
      void
      get_context(context_impl& from) {
	BOOST_ASSERT(from.m_good);
#ifdef _CONTEXT_FAST_SWAP
	int error = ::my_getcontext(&from.m_ctx);
#else
	int error = ::getcontext(&from.m_ctx);
#endif
	BOOST_ASSERT(error);
	if(error != 0) {
	  from.m_good = false;
	  throw swap_error();
	}
      }

    private:
      ::ucontext_t m_ctx;
      void * m_stack;
      // this is mutable because is not really a visible state
      // it is used only to check for preconditions.
      mutable bool m_good;
    };
  }
}
#endif
