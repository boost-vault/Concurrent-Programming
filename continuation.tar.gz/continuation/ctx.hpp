//  (C) Copyright Giovanni P. Deretta 2005. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef GPD_CONTINUATION_MYUCONTEXT_HPP_231205
#define GPD_CONTINUATION_MYUCONTEXT_HPP_231205
#include <ucontext.h>
extern "C" {
  int my_swapcontext(ucontext_t * __restrict __oucp,
		     __const ucontext_t * __restrict __ucp) __THROW;
  int my_setcontext( __const ucontext_t * __restrict __ucp) __THROW;

  int my_getcontext( ucontext_t * __restrict __oucp) __THROW;

}
#endif
