//  (C) Copyright Giovanni P. Deretta 2005. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef GDP_CONTEXT_EXCEPTION_HPP_21122005
#define GDP_CONTEXT_EXCEPTION_HPP_21122005
#include <exception>

namespace continuation {
  class swap_error: public std::exception {};
  class exit_exception:  public std::exception {};
}

#endif
