//  (C) Copyright Giovanni P. Deretta 2005. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef GDP_CONTINUATION_CONTEXT_BASE_21122005_HPP
#define GDP_CONTINUATION_CONTEXT_BASE_21122005_HPP
namespace continuation {

  namespace detail {
    /**
     * @todo This could be optimized using
     * with empty base optimization, but
     * it should detect the function pointer case
     */
    template<typename Functor>
    class base_from_member {
    public:
      base_from_member(Functor fun):
	m_functor(fun) {}

      Functor& functor() {
	return m_functor;
      }
    private:
      Functor m_functor;
    };
  }

  template<typename ContextImpl, typename Functor>
  class context_base :
    private detail::base_from_member<Functor>,
    public ContextImpl,
    private boost::noncopyable {
  public:
    typedef ContextImpl context_impl;
    explicit context_base(Functor fun) :
      detail::base_from_member<Functor>(fun),
      ContextImpl(functor()) {}
  private:
  };

#if 0
  template<typename ContextImpl>
  class context_base : 
    public ContextImpl, 
    private boost::noncopyable {
  public:
    typedef ContextImpl context_impl;
    typedef context_base<context_impl> type;
    typedef boost::intrusive_ptr<type> context_ptr;
      
    template<typename Functor>
    explicit context_base(Functor fun) :
      m_functor(fun),
      m_ctx(m_functor),
      m_counter(0),
      m_next(0) {}
                        
    template<typename ContextImpl_2>
    friend
    void intrusive_ptr_add_ref(context_base<ContextImpl_2> * ctx) {
      ctx->acquire();
    }
      
    template<typename ContextImpl_2>
    friend
    void intrusive_ptr_release(context_base<ContextImpl_2> * ctx) {
      ctx->release();
    }
      
    bool unique() const {
      return !count();
    }

    unsigned int count() const {
      return m_counter;
    }
    context_impl * impl() {
      return &m_ctx;
    }

    const context_impl * impl() const {
      return &m_ctx;
    }
      
    context_ptr next() {
      return m_next;
    }
     
    void next(context_ptr next) {
      m_next = next;
    }
  private:     
    void acquire() {
      m_counter ++;
    }
      
    void release() const {
      BOOST_ASSERT(m_counter);
      m_counter --;
      if(m_counter == 0) {
	delete this;
      }
    }
            
    boost::function<void ()> m_functor;
    context_impl m_ctx;
    mutable size_t m_counter;
    context_ptr m_next;
  };
    
#endif
}/* namespace continuation */

#endif
