//  (C) Copyright Giovanni P. Deretta 2005. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#include <boost/lexical_cast.hpp>
#include <boost/asio.hpp>
#include <continuation/scheduler.hpp>

boost::asio::demuxer demuxer;
static continuation::scheduler scheduler(demuxer);

void dummy (int) {}

int main(int argc, char ** argv) {
  int threads = (argc == 2? boost::lexical_cast<int>(argv[1]): 1000);
    
  for(; threads; threads--)
    scheduler.post(boost::bind(dummy, threads)); 
  demuxer.run(); 
} 
 
 
