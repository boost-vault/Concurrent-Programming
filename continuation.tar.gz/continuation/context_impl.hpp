//  (C) Copyright Giovanni P. Deretta 2005. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)



#ifndef GDP_CONTEXT_CONTEXT_IMPL_HPP_21122005
#define GDP_CONTEXT_CONTEXT_IMPL_HPP_21122005
#include <continuation/exception.hpp>
#include <continuation/context_posix.hpp>

namespace continuation {
  typedef posix::context_impl context_impl;
}

#endif
