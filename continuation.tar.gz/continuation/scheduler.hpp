//  (C) Copyright Giovanni P. Deretta 2005. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef GDP_CONTINUATION_SCHEDULER_HPP_32122005
#define GDP_CONTINUATION_SCHEDULER_HPP_32122005
#include <boost/asio.hpp>
#include <continuation/context_impl.hpp>
#include <continuation/scheduler_base.hpp>
namespace continuation {
  typedef scheduler_base<continuation::context_impl, boost::asio::demuxer> scheduler;
}
#endif
