// (c) Roland Schwarz 2005
#include "../thdmbrptr/include/thdmbrptr.hpp"
