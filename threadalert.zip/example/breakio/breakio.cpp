// (c) Roland Schwarz 2005
// breakio.cpp : Defines the entry point for the console application.
//

// This file does not contain operating system dependant code other than
// stdafx.h to keep msvc happy.
#include "stdafx.h"
#include "block.h"

#include <boostex/thdmbrptr.hpp>
#include <boostex/alert.hpp>

void sleep(int sec)
{
	boost::xtime t;
	boost::xtime_get(&t,1);	t.sec += sec; boost::thread::sleep(t);
}

// demonstrates how to alert a blocking call
void run1() {
	sleep(3);
	blocking_operation("\\\\.\\COM1");
	sleep(10);
}

boost::mutex m2;
boost::condition c2;
int v2 = 0;

// demonstrates how to make a condition alertable
void run2() {
	boost::mutex::scoped_lock lock(m2);
	// The alerter holds references to the mutex and
	// the condition, which will be bound together
	// during wait. So be sure to use the alerter
	// with narrower scope.
	boostex::alerter a(m2, c2);

	// We need to test also on the global alerted
	// state. The alerter gives access to an alerted()
	// function that can be used as a predicate,
	// whitout reseting the state.
	while(!a.alerted() && v2 == 0) 
		c2.wait(lock);
	
	// calling the free alerted function also
	// resets the thread alerted state
	if (!boostex::alerted())
		sleep(1);
}


int main(int argc, char* argv[])
{
	boostex::thread* pt1 = new boostex::thread(run1);
	boostex::thread* pt2 = new boostex::thread(run2);
	sleep(1);
	boostex::alert(pt2);
	boostex::alert(pt1);
	pt1->join();
	delete pt1;
	pt2->join();
	delete pt2;
	return 0;
}

