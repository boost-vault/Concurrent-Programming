// (c) Roland Schwarz 2005
#ifndef BLOCK_H_
#define BLOCK_H_

#include <string>

void blocking_operation(std::string sz);

#endif
