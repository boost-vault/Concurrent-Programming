// (c) Roland Schwarz 2005
#include "stdafx.h"
#include "block.h"

#include <windows.h>

#include <boostex/alert.hpp>
#include <boost/bind.hpp>

namespace {
	void Break(HANDLE h)
	{
		SetEvent(h);
	}
};


// This is a simple (nonsense) example to demonstrate
// how to break out of a blocking situation.
// Note that only this file contains operating system
// dependant code.
// The function tries to read data from the COM1 port
// using overlapped IO. After the read has been called
// we use WaitForMultipleObjects, one of which objects
// is set up as a means to cancel the blocking operation.
void blocking_operation(std::string sz)
{
	HANDLE evBreak = CreateEvent(NULL, TRUE, FALSE, NULL);
	HANDLE evRead = CreateEvent(NULL, TRUE, FALSE, NULL);
	OVERLAPPED ovRead ;
	memset(&ovRead, 0, sizeof(OVERLAPPED));
	ovRead.hEvent = evRead;

	unsigned char buf[256];
	DWORD dw;
	DWORD dwWait;

	HANDLE 	h = CreateFile(sz.c_str(),
		GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING,
		FILE_FLAG_OVERLAPPED, NULL);
	
	if (INVALID_HANDLE_VALUE != h) {
		while (true) {
			if (!ReadFile(h, buf, 256, &dw, &ovRead)) {
				if (ERROR_IO_PENDING == GetLastError()) {
					// The alerter holds a pointer to a function that
					// will be called when another thread wants
					// to alert us. When the alerter goes out of
					// scope the function will be set empty. So
					// there is no danger it might be called after
					// the evBreak HANDLE has been closed.
					boostex::alerter a(boost::bind(Break, evBreak));
					ResetEvent(evBreak);
					HANDLE ev[2] = {evRead, evBreak};
					if (a.alerted()) // In case the alert() was called before 
						             // Break has been registered.
						dwWait = WAIT_OBJECT_0+1;
					else
						dwWait = WaitForMultipleObjects(2, ev, FALSE, INFINITE);
					if (WAIT_OBJECT_0 == dwWait) {
						if (!GetOverlappedResult(h, &ovRead, &dw, FALSE))
							break;
					}
					else if (WAIT_OBJECT_0+1 == dwWait) {
						// we have been requested to break out
						CancelIo(h);
						// clear the alerted state
						boostex::alerted();
						break;
					}
					else
						break; // we are simply breaking out in case of 
					           // this unexpected result.
					           // Production code will need to do something
					           // smarter.
				}
			}
		}
		CloseHandle(h);
	}

	CloseHandle(evRead);
	CloseHandle(evBreak);
}

