// (c) Roland Schwarz 2005
// shared.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <boostex/thdmbrptr.hpp>
#include <boost/thread.hpp>

// A state class living in shared memory.
// The class has its own sync mechanism.
class state {
public:
	state() : result(0)
	{}
	void set_result(int n)
	{
		boost::mutex::scoped_lock lock(monitor);
		result = n;
	}
	int get_result()
	{
		boost::mutex::scoped_lock lock(monitor);
		return result;
	}
private:
	boost::mutex monitor;
	int result;
};

// The thread member pointer.
// Its syntax is almost the same when used
// from "inside" a thread as that of the
// thread_specific_ptr. I named it public
// to underpin the fact it is accessible
// from "outside" too. (Perhaps other names
// than thread_member_ptr and thread_specific_ptr
// would be more appropriate? Any suggestions?
// E.g. thread_public_ptr and thread_private_ptr?)
boostex::thread_member_ptr<state> public_state;

// The conventional tss pointer.
// It can be seen as a memory space that is
// only privately accessible by the thread,
// when interpreted in our context.
boost::thread_specific_ptr<int> private_int;

// It might be convenient to have a function
// that is called automatically on thread start
// up to auto initialize the variables.
// (Perhaps it should be coined thread_ctor?)
void init_state_fn()
{
	public_state.reset(new state);
	private_int.reset(new int(0));
}

// The ctor of the below object registers
// a chain of functions to be called on
// every thread startup. You can have any
// number of this objects to add to this
// chain from different translation units.
// (Perhaps a better name would be:
// boostex::thread_ctor ?)
boostex::thread::init init_state(init_state_fn);

// The threaded function. Note that we do
// not put any restrictions/requirements on
// its parameters.
void run()
{
	// We do not much interseting here,
	// just set the result and exit.
	// However we can be sure, the initializers
	// have been run, so it is safe to simply
	// access the state object.
	public_state->set_result(42);
}

int main(int argc, char* argv[])
{
int result;

	// boostex contains a thread class that is
	// derived from boost::thread. Using the shared_ptr
	// concept the lifetime of member pointers targets
	// is tied to existence of the instance of this 
	// boostex::thread class
	// _and_
	// the existence of the "real" thread (by means of
	// an underlying tss)
	// _and_
	// any shared pointers that have been obtained.
	// If the original boost::thread had a virtual
	// destructor, we even could store the pointer
	// to a normal boost::thread*.
	boostex::thread* th = new boostex::thread(run);

	// Now we obtain a shared pointer from the member
	// pointer. Since we cannot be sure the inializer
	// has finished yet, we opt to also wait until it
	// has been assigned. (Note: memory allocation is
	// only from inside the thread.)
	// The specific instance of the object from the
	// member pointer is indexed by thread*. Since it
	// is unique (thread is noncopyable!) it does 
	// well as a unique thread id. (Altough I would
	// rather like to see a "real" thread id for this.
	// But this isn't possible without modifying boost::thread.)
	boost::shared_ptr<state> ths = public_state.wait_and_get(th);

	// Note, that it is not a requirement to obtain
	// and hold a shared_ptr to the object. The pointer
	// also can be accessed by the below construct.
	// Since the [] operator also does hand back a
	// shared pointer, calling into the object again
	// is safe, even in the case the thread _and_
	// the boostex::thread instance are dying while
	// the call is in the get_result function.
	result = public_state[th]->get_result();

	// Now we are about to get rid of the thread.
	// If you want to omit the below join, this
	// would be ok. This would be the semantics
	// of "detaching" in pthread speak. Since we
	// still do have a shared_ptr to the state
	// however, we are still would be able to query
	// the result from the detached thread.
	th->join();

	// delete the thread instance
	delete th;

	// We still may access the state object by
	// means of the shared_ptr.
	result = ths->get_result();

	return 0;
}

