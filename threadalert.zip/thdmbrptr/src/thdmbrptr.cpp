// (c) Roland Schwarz 2005
#include "../include/thdmbrptr.hpp"
#include <boost/bind.hpp>

namespace boostex {
	namespace detail {

		boost::thread_specific_ptr<boost::shared_ptr<tds> > this_tds;

		tds::tds(const boost::function0<void>& thdfn)
			: threadfunc(thdfn), started(false), 
			threadid(0), is_detached(false)
		{
		}

		void tds::threadfunc_proxy() 
		{
			{
				boost::mutex::scoped_lock lock(monitor);
				this_tds.reset(new boost::shared_ptr<tds>());
				*this_tds = shared_from_this();
				while(0 == threadid) changed.wait(lock);
				started = true;
				changed.notify_one();
			}
			thread::init::func();
			threadfunc();
		}

		void tds::wait_until_started() 
		{
			boost::mutex::scoped_lock lock(monitor);
			while (!started) changed.wait(lock);
		}

		void tds::set_threadid(boost::thread* id)
		{
			boost::mutex::scoped_lock lock(monitor);
			threadid = id;
			changed.notify_one();
		}

		void tds::detach()
		{
			boost::mutex::scoped_lock lock(update);
			std::set<detail::thread_member_ptr_base*>::const_iterator i;
			for (i = mptb.begin(); i != mptb.end(); ++i)
				(*i)->detach(threadid);
			mptb.clear();
			is_detached = true;
		}
	};

	thread::thread(const boost::function0<void>& threadfunc)
		: boost::base_from_member<boost::shared_ptr<detail::tds> >(new detail::tds(threadfunc))
		, boost::thread(boost::bind(&detail::tds::threadfunc_proxy, member))
	{
		member->set_threadid(this);
		member->wait_until_started();
		// at this point, member has three references:
		// member itself, via copy of threadfunc_proxy pointer and this_tds
	}

	thread::~thread()
	{
		member->detach();
	}

	thread::init* thread::init::last = 0;

	thread::init::init(const boost::function0<void>& inifn)
		: initfunc(inifn), prev(last)
	{
		// the constructor is thread-safe because it is only used on
		// global objects which are constructed before any threads
		last = this;
	}

	void thread::init::func()
	{
		init* p = last;
		while (0 != p) {
			(p->initfunc)();
			p = p->prev;
		}
	}
};

