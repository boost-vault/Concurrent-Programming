// (c) Roland Schwarz 2005
#ifndef THDMBRPTR_HPP_
#define THDMBRPTR_HPP_

#include <boost/thread.hpp>
#include <boost/function.hpp>
#include <boost/utility.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <map>
#include <set>

namespace boostex {
	namespace detail {

		class thread_member_ptr_base : private boost::noncopyable
		{
		public:
			virtual void detach(boost::thread* pt) = 0;
		};

		class tds : public boost::enable_shared_from_this<tds>
		{
		public:
			tds(const boost::function0<void>& thdfn);
			~tds() {
			}
			void threadfunc_proxy();
			void set_threadid(boost::thread* id);
			void wait_until_started();
			void detach();
			const boost::function0<void> threadfunc;
			boost::thread* threadid;
			boost::mutex update;
				bool is_detached;
				std::set<thread_member_ptr_base*> mptb;
		private:
			boost::mutex monitor;
				boost::condition changed;
				bool started;
		};

		extern boost::thread_specific_ptr<boost::shared_ptr<tds> > this_tds;


	};

	class thread 
		: private boost::base_from_member<boost::shared_ptr<detail::tds> >
	, public boost::thread
	{
	public:
		explicit thread(const boost::function0<void>& threadfunc);
		~thread();
		class init
		{
		public:
			init(const boost::function0<void>& inifn);
			static void func();
		private:
			const boost::function0<void> initfunc;
			static init* last;
			init* prev;
		};
	};

	template <typename T>
	class thread_member_ptr : public detail::thread_member_ptr_base
	{
	public:
		thread_member_ptr()
		{
		}

		T* get() const {
			if (0 == mpt.get())	return 0;
			else return mpt.get()->get(); 
		}
		
		T* operator->() const { 
			if (0 == mpt.get())	return 0;
			else return mpt.get()->get(); 
		}
		
		T& operator*() const { 
			return *(mpt.get()->get()); 
		}
		
		void reset(T* p=0) {
			boost::shared_ptr<T>* psp(new boost::shared_ptr<T>(p));
			mpt.reset(psp);
			boost::shared_ptr<detail::tds> ptds(*detail::this_tds);
			if (ptds) {
				boost::mutex::scoped_lock update_lock(ptds->update);
				if (!ptds->is_detached) {
					boost::mutex::scoped_lock lock(monitor);
					tmap[ptds->threadid] = *psp;
					ptds->mptb.insert(this);
					mapchanged.notify_all();
				}
			}
		}

		boost::shared_ptr<T> operator[](boost::thread* pt) {
			std::map<boost::thread*, boost::shared_ptr<T> >::const_iterator i;
			boost::mutex::scoped_lock lock(monitor);
			
			i = tmap.find(pt);
			if ( i == tmap.end())
				return boost::shared_ptr<T>();
			else
				return boost::shared_ptr<T>(i->second);
		}
		
		boost::shared_ptr<T> wait_and_get(boost::thread* pt) {
			std::map<boost::thread*, boost::shared_ptr<T> >::const_iterator i;
			boost::mutex::scoped_lock lock(monitor);
			while ((i = tmap.find(pt)) == tmap.end())
				mapchanged.wait(lock);
			return boost::shared_ptr<T>(i->second);
		}

		// detach is not considered part of the user interface
		virtual void detach(boost::thread* pt) {
			boost::mutex::scoped_lock lock(monitor);
			tmap.erase(pt);
		}

	private:
		boost::mutex monitor;
		boost::condition mapchanged;
		boost::thread_specific_ptr<boost::shared_ptr<T> > mpt;
		std::map<boost::thread*, boost::shared_ptr<T> > tmap;
	};
};

#endif /* THDMBRPTR_HPP_ */