// (c) Roland Schwarz 2005
#include "../include/alert.hpp"

#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boostex/thdmbrptr.hpp>

namespace {

	class alarm {
	public:
		alarm() : is_alerted(false)
		{}
		void alert()
		{
			boost::mutex::scoped_lock lock(monitor);
			if (!is_alerted) {
				is_alerted = true;
				if (!alerter.empty())
					alerter();
			}
		}
		bool alerted()
		{
			boost::mutex::scoped_lock lock(monitor);
			bool t(is_alerted);
			is_alerted = false;
			return t;
		}
		void set_alerter(const boost::function0<void>& fn)
		{
			boost::mutex::scoped_lock lock(monitor);
			alerter = fn;
		}
		void clear_alerter()
		{
			boost::mutex::scoped_lock lock(monitor);
			alerter = 0;
		}
		bool is_alerted;
	private:
		boost::mutex monitor;
		boost::function0<void> alerter;
	};
	
	boostex::thread_member_ptr<alarm> thread_alarm;

	void init_alert()
	{
		thread_alarm.reset(new alarm);
	}

	boostex::thread::init init_alert_fn(init_alert);

	// convenience alerter function
	void condition_alerter(boost::mutex& m, boost::condition& c)
	{
		boost::mutex::scoped_lock lock(m);
		c.notify_all();
	}
};

namespace boostex {
	void alert(boost::thread* th)
	{
		thread_alarm[th]->alert();
	}

	bool alerted()
	{
		return thread_alarm->alerted();
	}
	
	alerter::alerter(const boost::function0<void>& fn)
	{
		thread_alarm->set_alerter(fn);
	}
	
	alerter::alerter(boost::mutex& m, boost::condition& c)
	{
		thread_alarm->set_alerter(
			boost::bind(condition_alerter,boost::ref(m),boost::ref(c)));
	}

	alerter::~alerter()
	{
		thread_alarm->clear_alerter();
	}

	bool alerter::alerted() const
	{
		return thread_alarm->is_alerted;
	}

};