// (c) Roland Schwarz 2005
#ifndef ALERT_HPP_
#define ALERT_HPP_

#include <boost/thread.hpp>
#include <boost/function.hpp>

namespace boostex {
	void alert(boost::thread* th);
	// alert a different thread by setting a flag
	// and call the registered alerter function

	bool alerted();
	// returns true if the thread is alerted
	// resets the alerted state to false

	class alerter {
	public:
		explicit alerter(const boost::function0<void>& fn);
		// ctor registers the alerter function
		// The function will run in the context of
		// the thread that calls alert(boost::thread*)
		explicit alerter(boost::mutex& m, boost::condition& c);
		~alerter();
		// dtor unregisters the alerter function
		bool alerted() const;
		// Test the alerted state without clearing it.
		// Can be used as a predicate.
	};
};

#endif /* ALERT_HPP_ */