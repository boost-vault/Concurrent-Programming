//////////////////////////////////////////////////////////////////////////////
//
// (C) Copyright Roland Schwarz 2006. 
// (C) Copyright Vicente J. Botet Escriba 2008-2009. 
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/interthreads for documentation.
//
// Based on the shared.cpp example from the threadalert library of Roland Schwarz 
//////////////////////////////////////////////////////////////////////////////

#include <boost/thread/mutex.hpp>
#include <boost/thread/thread.hpp>
boost::mutex out_global_mutex;

void sleep(int sec)
{
    boost::xtime t;
    boost::xtime_get(&t,1);
    t.sec += sec; 
    boost::thread::sleep(t);
}


#include <boost/interthreads/thread_tuple.hpp>
#include <boost/interthreads/thread_tuple_once.hpp>
#include <boost/interthreads/thread_group_once.hpp>
#include <boost/interthreads/thread_and_join.hpp>
#include <boost/interthreads/typeof/threader.hpp>
#include <boost/interthreads/wait_for_any.hpp>
#include <boost/thread.hpp>
#include <iostream>
        
namespace bith = boost::interthreads;

int my_thread1() {
    sleep(3);
    {
        boost::lock_guard<boost::mutex> lock(out_global_mutex);
        std::cout << "1 thread_id=" << boost::this_thread::get_id() << std::endl;
    }
    return 0;
}
    
int my_thread2() {
    sleep(1);
    {
        boost::lock_guard<boost::mutex> lock(out_global_mutex);
        std::cout << "2 thread_id=" << boost::this_thread::get_id() << std::endl;
    }
    return 0;
}

int my_thread3() {
    sleep(2);
    {
        boost::lock_guard<boost::mutex> lock(out_global_mutex);
        std::cout << "3 thread_id=" << boost::this_thread::get_id() << std::endl;
    }
    return 0;
}


int main() {
    bith::shared_threader ae;
    BOOST_AUTO(result,bith::wait_for_any(ae, my_thread1, my_thread2, my_thread3));
    std::cout << "Algotithm " << result.first+1 << " finished the first with wait_for_any result=" << result.second << std::endl;


#if 0
    //BOOST_AUTO(handles,bith::fork_all(ae, my_thread1, my_thread2, my_thread3));
    
    bith::thread_tuple<3> tt_0(my_thread1, my_thread2, my_thread3);
    bith::thread_tuple<3> tt_1;
    tt_1= tt_0.move();
    bith::thread_tuple<3> tt_2(tt_1.move());
    bith::thread_tuple<3> tt(boost::move(tt_2));

    tt.join_all();
    std::cout << "All finished join_all" << std::endl;
        
    bith::thread_tuple<3> kk_0= bith::make_thread_tuple(my_thread1, my_thread2, my_thread3);
    kk_0.join_all();
    std::cout << "All finished join_all" << std::endl;
        
    bith::thread_group_once tgo;
    boost::thread* th1 = tgo.create_thread(my_thread1);
    boost::thread* th2 = tgo.create_thread(my_thread2);
    boost::thread* th3 = tgo.create_thread(my_thread3);
    boost::thread* res_tgo= tgo.join_any();
    std::cout << "Algotithm " << res_tgo << " " << th2 << " finished the first with thread_group_once::join_any" << std::endl;
        
       
    bith::conc_join_all(my_thread1, my_thread2, my_thread3);
    std::cout << "All finished conc_join_all" << std::endl;

    unsigned res = bith::conc_join_any(my_thread1, my_thread2, my_thread3);
    std::cout << "Algotithm " << res+1 << " finished the first with conc_join_any" << std::endl;
#endif        
        
    return 0;
}
